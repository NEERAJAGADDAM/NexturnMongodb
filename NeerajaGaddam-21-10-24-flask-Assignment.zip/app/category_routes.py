from flask import Blueprint, render_template, request, redirect, url_for

category = Blueprint('category', __name__)

# In-memory storage for categories (for demonstration purposes)
categories = []

@category.route('/categories')
def category_index():
    return render_template('catogeries/index.html', categories=categories)

@category.route('/categories/create', methods=['GET', 'POST'])
def create_category():
    if request.method == 'POST':
        # Get form data
        category_id = request.form.get('id')
        category_name = request.form.get('name')
        category_price = request.form.get('price')
        
        # Add new category to the list
        new_category = {'id': category_id, 'name': category_name, 'price': category_price}
        categories.append(new_category)
        
        # Redirect to the category index page after successful creation
        return redirect(url_for('category.category_index'))
    
    # Render the category creation form for GET requests
    return render_template('catogeries/create.html')

@category.route('/categories/update/<int:id>', methods=['GET', 'POST'])
def update_category(id):
    if id >= len(categories) or id < 0:
        return "Category not found", 404 
    
    if request.method == 'POST':
        updated_id = request.form['id']
        updated_name = request.form['name']
        updated_price = request.form['price']
        
        # Update category by id
        categories[id]['id'] = updated_id
        categories[id]['name'] = updated_name
        categories[id]['price'] = updated_price
        
        # Redirect to the category index page after successful update
        return redirect(url_for('category.category_index'))
    
    # For GET request, render the update form with category data
    category_to_update = categories[id]
    return render_template('catogeries/update.html', category=category_to_update, id=id)

@category.route('/categories/delete/<int:id>', methods=['GET', 'POST'])
def delete_category(id):
    if id >= len(categories) or id < 0:
        return "Category not found", 404  
    
    if request.method == 'POST':
        # Remove the category by id
        categories.pop(id)
        # Redirect to the category index page after successful deletion
        return redirect(url_for('category.category_index'))

    # Render the confirmation page
    category_to_delete = categories[id]
    return render_template('catogeries/delete.html', category=category_to_delete, id=id)
