from flask import Blueprint, render_template, request, redirect, url_for

product = Blueprint('product', __name__)

# In-memory storage for products (for demonstration purposes)
products = []

@product.route('/')
def product_index():
    return render_template('products/index.html', products=products)

# To create a product
@product.route('/create', methods=['GET', 'POST'])
def create_product():
    if request.method == 'POST':
        # Get form data
        product_id = request.form.get('id')
        product_name = request.form.get('name')
        product_price = request.form.get('price')

        # Add new product to the list (you can replace this with a database in production)
        new_product = {'id': product_id, 'name': product_name, 'price': product_price}
        products.append(new_product)

        # Redirect to the product index page after successful creation
        return redirect(url_for('product.product_index'))

    # Render the product creation form for GET requests
    return render_template('products/create.html')

# To update a product
@product.route('/update/<int:id>', methods=['GET', 'POST'])
def update_product(id):
    if id >= len(products) or id < 0:
        return "Product not found", 404  # Ensure the product id is valid

    if request.method == 'POST':
        updated_id = request.form['id']
        updated_name = request.form['name']
        updated_price = request.form['price']

        # Update product by id (assuming id is the index)
        products[id]['id'] = updated_id
        products[id]['name'] = updated_name
        products[id]['price'] = updated_price

        # Redirect to the product index page after successful update
        return redirect(url_for('product.product_index'))

    # For GET request, render the update form with product data
    product_to_update = products[id]
    return render_template('products/update.html', product=product_to_update, id=id)

# To delete a product
@product.route('/delete/<int:id>', methods=['GET', 'POST'])
def delete_product(id):
    if id >= len(products) or id < 0:
        return "Product not found", 404  # Ensure the product id is valid

    if request.method == 'POST':
        # Remove the product by id (assuming id is the index in the list)
        products.pop(id)

        # Redirect to the product index page after successful deletion
        return redirect(url_for('product.product_index'))

    # Render the confirmation page
    product_to_delete = products[id]
    return render_template('products/delete.html', product=product_to_delete, id=id)


