from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from functools import wraps  # To use with login_required

auth_routes = Blueprint('auth_routes', __name__)

# Hardcoded user data for demonstration purposes (in reality, you would store this in a database)
users = {
    "admin": "123456",
    "user": "123456"
}

# Login required decorator
def login_required(view):
    @wraps(view)
    def wrapped_view(**kwargs):
        if 'username' not in session:
            return redirect(url_for('auth_routes.login'))
        return view(**kwargs)
    return wrapped_view

@auth_routes.route('/public')
def public():
    return "This is a public page."

@auth_routes.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        
        # Check if the username exists in the users dict and if the password matches
        if username in users and users[username] == password:
            session['username'] = username
            return redirect(url_for('main.home'))  # Redirect to home or dashboard after successful login
        else:
            flash('Login Failed! Try Again.', 'danger')
    
    return render_template('auth/login.html', title='Login')

@auth_routes.route('/dashboard')
@login_required
def dashboard():
    return render_template('auth/dashboard.html', username=session['username'])

@auth_routes.route('/logout')
def logout():
    session.pop('username', None)
    flash('You have successfully logged out.', 'success')
    return redirect(url_for('auth_routes.thankyou'))

# Signup route
@auth_routes.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check if the username already exists
        if username in users:
            flash('Username already exists, please choose another one.', 'danger')
        else:
            users[username] = password
            flash('Account created successfully! Please login.', 'success')
            return redirect(url_for('auth_routes.login'))
    
    return render_template('auth/signup.html', title='Sign Up')

@auth_routes.route('/thankyou')
def thankyou():
    return render_template('auth/thankyou.html', title="Thank You")
