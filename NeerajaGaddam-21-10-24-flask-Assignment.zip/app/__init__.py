from flask import Flask
import secrets  # Import the secrets module

def create_app():
    app = Flask(__name__)

    # Set a secret key for sessions and cryptographic tasks
    app.secret_key = secrets.token_hex(16)
    
    # Importing blueprints
    from .routes import main  # Assuming 'main' is the blueprint in routes.py
    from .product_routes import product  # Assuming 'product' is the blueprint in product_routes.py
    from .category_routes import category  # Assuming 'category' is the blueprint in category_routes.py
    from .auth_routes import auth_routes  # Assuming 'auth_routes' is the blueprint in auth_routes.py
    
    # Register blueprints
    app.register_blueprint(main)
    app.register_blueprint(product, url_prefix='/products')
    app.register_blueprint(category, url_prefix='/categories')
    app.register_blueprint(auth_routes)
    
    return app




